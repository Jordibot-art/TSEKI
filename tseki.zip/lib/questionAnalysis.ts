import AsyncStorage from "@react-native-async-storage/async-storage";

// ── Types ─────────────────────────────────────────────────────────────────────
export type DifficultyLevel = "Easy" | "Moderate" | "Difficult";

export function getDifficultyLevel(p: number): DifficultyLevel {
  if (p >= 0.75) return "Easy";
  if (p >= 0.25) return "Moderate";
  return "Difficult";
}

export interface StudentQuestionResult {
  questionNumber: number;
  questionText?: string;
  questionType?: string;
  studentAnswer: string;
  correctAnswer: string;
  isCorrect: boolean;
  pointsAwarded: number;
}

export interface StudentQuizResult {
  studentId: string;
  studentName: string;
  classroomId: string;
  quizId?: string | null;
  quizTitle: string;
  scorePercentage: number;
  totalScore: number;
  maxScore: number;
  results: StudentQuestionResult[];
  gradedAt: string;
}

export interface DistractorOptionStat {
  option: string;
  count: number;
  percentage: number;
  isCorrect: boolean;
}

export interface StudentMissedDetail {
  studentId?: string;
  studentName: string;
  studentAnswer: string;
}

export interface QuestionAnalysisSummary {
  questionNumber: number;
  questionText?: string;
  questionType?: string;
  correctAnswer: string;
  options?: string[];
  totalAttempts: number;
  correctCount: number;
  incorrectCount: number;
  accuracyRate: number; // 0-100%
  missedRate: number; // 0-100%
  difficultyIndex: number; // 0.00 to 1.00 (p-value = correctCount / totalAttempts)
  difficultyLevel: DifficultyLevel; // "Easy" (>=0.75), "Moderate" (0.25-0.74), "Difficult" (<0.25)
  distractorCounts: Record<string, number>; // e.g. { "A": 2, "B": 6, "C": 1 }
  distractorBreakdown: DistractorOptionStat[];
  mostCommonMistake?: {
    answer: string;
    count: number;
    percentage: number;
  };
  pedagogicalInsight?: string;
  studentsMissed: string[]; // names of students who got it wrong
  studentsMissedDetails: StudentMissedDetail[];
  studentsCorrect: string[];
}

export interface ClassQuizAnalysis {
  quizTitle: string;
  totalStudentsGraded: number;
  classAverageScore: number;
  averageDifficultyIndex: number; // average p-value across all questions
  difficultyBreakdown: {
    easyCount: number;
    moderateCount: number;
    difficultCount: number;
  };
  questionBreakdown: QuestionAnalysisSummary[];
  mostMissedQuestions: QuestionAnalysisSummary[]; // sorted by highest missed rate / lowest p-value
  hardestQuestions: QuestionAnalysisSummary[]; // alias for mostMissedQuestions
  easiestQuestions: QuestionAnalysisSummary[];
  overallRecommendation: string;
}

// ── Storage Keys ──────────────────────────────────────────────────────────────
const RESULTS_PREFIX = "tseki_quiz_results_";

function getStorageKey(classroomId: string): string {
  return `${RESULTS_PREFIX}${classroomId}`;
}

function isUuidLike(val?: string | null): boolean {
  return Boolean(
    val &&
      /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(val.trim())
  );
}

/**
 * Prevents two distinct assessments that happen to share the exact same title
 * (e.g., a 20-item quiz and a 5-item quiz with the same topic title) from overwriting
 * each other in AsyncStorage or Supabase's UNIQUE(student_id, classroom_id, quiz_title).
 * Re-scanning the exact same assessment (matching quizId or matching title + maxScore)
 * still updates cleanly in place.
 */
export function resolveNonCollidingQuizTitle(
  existingStudentResults: StudentQuizResult[],
  incoming: Pick<StudentQuizResult, "quizId" | "quizTitle" | "maxScore" | "gradedAt">
): string {
  const baseTitle = (incoming.quizTitle || "Assessment").trim();
  const normBase = baseTitle.toLowerCase();
  const incomingId = (incoming.quizId || "").trim();

  // 1. If an existing entry already matches this exact quizId, reuse its stored title so re-grading updates in place
  if (incomingId) {
    const sameIdMatch = existingStudentResults.find(
      (r) => (r.quizId || "").trim() === incomingId
    );
    if (sameIdMatch?.quizTitle) {
      return sameIdMatch.quizTitle;
    }
  }

  // 2. Check if baseTitle is unused or belongs to the exact same assessment (same maxScore & no conflicting quizId)
  const sameTitleExisting = existingStudentResults.find(
    (r) => (r.quizTitle || "").trim().toLowerCase() === normBase
  );
  if (!sameTitleExisting) {
    return baseTitle;
  }

  const existingId = (sameTitleExisting.quizId || "").trim();
  const hasConflictingId = Boolean(incomingId && existingId && incomingId !== existingId);
  const hasDifferentMaxScore =
    Number(sameTitleExisting.maxScore || 0) > 0 &&
    Number(incoming.maxScore || 0) > 0 &&
    Number(sameTitleExisting.maxScore) !== Number(incoming.maxScore);

  if (!hasConflictingId && !hasDifferentMaxScore) {
    return sameTitleExisting.quizTitle || baseTitle;
  }

  // 3. Different assessment sharing the same title -> disambiguate with item/point count
  const withPts = `${baseTitle} (${incoming.maxScore} pts)`;
  const normWithPts = withPts.toLowerCase();
  const ptsCollision = existingStudentResults.find(
    (r) => (r.quizTitle || "").trim().toLowerCase() === normWithPts
  );
  if (
    !ptsCollision ||
    (!incomingId && Number(ptsCollision.maxScore) === Number(incoming.maxScore)) ||
    (incomingId && (ptsCollision.quizId || "").trim() === incomingId)
  ) {
    return withPts;
  }

  const dateTag = new Date(incoming.gradedAt || Date.now()).toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
  });
  return `${baseTitle} (${incoming.maxScore} pts · ${dateTag})`;
}

// ── Save Per-Student Quiz Results ─────────────────────────────────────────────
/**
 * Persists a student's per-question grading results for later analysis.
 * Stores one entry per student per distinct quiz (updates if regraded) in both local
 * AsyncStorage and Supabase `student_quiz_results`.
 */
export async function saveStudentQuizResult(
  result: StudentQuizResult
): Promise<void> {
  const key = getStorageKey(result.classroomId);
  let effectiveResult: StudentQuizResult = { ...result };

  try {
    let existing: StudentQuizResult[] = [];
    try {
      const json = await AsyncStorage.getItem(key);
      if (json) existing = JSON.parse(json);
    } catch {
      existing = [];
    }

    const sameStudentExisting = existing.filter((r) => r.studentId === result.studentId);
    const resolvedTitle = resolveNonCollidingQuizTitle(sameStudentExisting, result);
    effectiveResult = { ...result, quizTitle: resolvedTitle };

    // Remove previous entry for same student + resolved quiz (if regraded)
    const normResolved = resolvedTitle.trim().toLowerCase();
    const filtered = existing.filter(
      (r) =>
        !(
          r.studentId === effectiveResult.studentId &&
          (r.quizTitle || "").trim().toLowerCase() === normResolved
        )
    );

    filtered.push(effectiveResult);
    await AsyncStorage.setItem(key, JSON.stringify(filtered));
  } catch (err) {
    console.error("Failed to save student quiz result locally:", err);
  }

  // Also sync to Supabase `student_quiz_results` table if available
  try {
    if (process.env.EXPO_PUBLIC_SUPABASE_URL && effectiveResult.studentId && effectiveResult.classroomId) {
      const { supabase } = await import("../supabase");
      const payload: any = {
        student_id: effectiveResult.studentId,
        classroom_id: effectiveResult.classroomId,
        quiz_id: effectiveResult.quizId || null,
        quiz_title: effectiveResult.quizTitle,
        total_score: effectiveResult.totalScore,
        max_score: effectiveResult.maxScore,
        score_percentage: effectiveResult.scorePercentage,
        item_results: effectiveResult.results || [],
        graded_at: effectiveResult.gradedAt || new Date().toISOString(),
      };
      const { error: upsertErr } = await supabase.from("student_quiz_results").upsert(
        payload,
        { onConflict: "student_id,classroom_id,quiz_title" }
      );
      if (upsertErr && (upsertErr.code === "PGRST204" || upsertErr.message?.includes("quiz_id"))) {
        const { quiz_id, ...fallbackPayload } = payload;
        await supabase.from("student_quiz_results").upsert(
          fallbackPayload,
          { onConflict: "student_id,classroom_id,quiz_title" }
        );
      }

      // Recalculate student's average across all quizzes in this classroom
      await recalculateStudentAverage(effectiveResult.studentId, effectiveResult.classroomId);
    }
  } catch (cloudErr) {
    console.warn("Could not sync student quiz result to Supabase:", cloudErr);
  }
}

/**
 * Pure helper to validate and compute an updated StudentQuizResult entry
 * when a teacher edits a quiz grade inside the Student Profile grade sheet.
 */
export function computeEditedGradeEntry(
  original: StudentQuizResult,
  edits: { quizTitle?: string; totalScore: number; maxScore: number }
): StudentQuizResult {
  const cleanTitle = (edits.quizTitle || original.quizTitle || "Assessment").trim() || "Assessment";
  const safeMax = Math.max(1, Math.round(Number(edits.maxScore) * 100) / 100 || 1);
  const rawScore = Number.isFinite(Number(edits.totalScore)) ? Number(edits.totalScore) : 0;
  const safeScore = Math.max(0, Math.min(safeMax, Math.round(rawScore * 100) / 100));
  const newPercentage = Math.round((safeScore / safeMax) * 100);

  return {
    ...original,
    quizTitle: cleanTitle,
    totalScore: safeScore,
    maxScore: safeMax,
    scorePercentage: newPercentage,
  };
}

/**
 * Updates an individual quiz grade entry for a student in both AsyncStorage and Supabase
 * `student_quiz_results`, then recalculates the student's cumulative average in `students`.
 */
export async function updateStudentQuizResult(params: {
  classroomId: string;
  studentId: string;
  studentName?: string;
  original: StudentQuizResult;
  newQuizTitle: string;
  newTotalScore: number;
  newMaxScore: number;
}): Promise<{ results: StudentQuizResult[]; newAverage: number }> {
  const { classroomId, studentId, studentName, original, newQuizTitle, newTotalScore, newMaxScore } = params;
  const key = getStorageKey(classroomId);

  const edited = computeEditedGradeEntry(original, {
    quizTitle: newQuizTitle,
    totalScore: newTotalScore,
    maxScore: newMaxScore,
  });

  const origNormTitle = (original.quizTitle || "").trim().toLowerCase();
  const newNormTitle = (edited.quizTitle || "").trim().toLowerCase();

  // 1. Update local AsyncStorage cache
  try {
    let existing: StudentQuizResult[] = [];
    const json = await AsyncStorage.getItem(key);
    if (json) existing = JSON.parse(json);

    let replaced = false;
    const nextList: StudentQuizResult[] = [];
    for (const r of existing) {
      const sameStudent = r.studentId === original.studentId || r.studentId === studentId;
      const rNorm = (r.quizTitle || "").trim().toLowerCase();
      if (sameStudent && rNorm === origNormTitle) {
        if (!replaced) {
          nextList.push({ ...edited, studentId });
          replaced = true;
        }
        continue;
      }
      // If renamed to match another existing entry, avoid leaving duplicate
      if (sameStudent && rNorm === newNormTitle && newNormTitle !== origNormTitle) {
        continue;
      }
      nextList.push(r);
    }
    if (!replaced) {
      nextList.push({ ...edited, studentId });
    }
    await AsyncStorage.setItem(key, JSON.stringify(nextList));
  } catch (err) {
    console.error("Failed to update student quiz result locally:", err);
  }

  // 2. Sync to Supabase `student_quiz_results`
  try {
    if (process.env.EXPO_PUBLIC_SUPABASE_URL && studentId && classroomId) {
      const { supabase } = await import("../supabase");

      // If the teacher renamed the quiz title, remove the old title key first so no ghost entry remains
      if (origNormTitle !== newNormTitle) {
        await supabase
          .from("student_quiz_results")
          .delete()
          .eq("student_id", studentId)
          .eq("classroom_id", classroomId)
          .eq("quiz_title", original.quizTitle);
      }

      const payload: any = {
        student_id: studentId,
        classroom_id: classroomId,
        quiz_id: edited.quizId || null,
        quiz_title: edited.quizTitle,
        total_score: edited.totalScore,
        max_score: edited.maxScore,
        score_percentage: edited.scorePercentage,
        item_results: edited.results || [],
        graded_at: edited.gradedAt || new Date().toISOString(),
      };
      const { error: upsertErr } = await supabase
        .from("student_quiz_results")
        .upsert(payload, { onConflict: "student_id,classroom_id,quiz_title" });
      if (upsertErr && (upsertErr.code === "PGRST204" || upsertErr.message?.includes("quiz_id"))) {
        const { quiz_id, ...fallbackPayload } = payload;
        await supabase
          .from("student_quiz_results")
          .upsert(fallbackPayload, { onConflict: "student_id,classroom_id,quiz_title" });
      }
    }
  } catch (cloudErr) {
    console.warn("Could not sync edited student quiz result to Supabase:", cloudErr);
  }

  const recalculated = await recalculateStudentAverage(studentId, classroomId);
  const finalAvg = recalculated >= 0 ? recalculated : edited.scorePercentage;
  const refreshed = await getStudentResults(classroomId, studentId, studentName);
  return { results: refreshed, newAverage: finalAvg };
}

/**
 * Deletes a single recorded assessment entry from a student's Quiz Grade Sheet
 * in both AsyncStorage and Supabase `student_quiz_results`, then recalculates
 * the student's cumulative average (resetting to 0 when no entries remain).
 */
export async function deleteStudentQuizResult(params: {
  classroomId: string;
  studentId: string;
  studentName?: string;
  target: StudentQuizResult;
}): Promise<{ results: StudentQuizResult[]; newAverage: number }> {
  const { classroomId, studentId, studentName, target } = params;
  const key = getStorageKey(classroomId);
  const normTargetTitle = (target.quizTitle || "").trim().toLowerCase();

  // 1. Remove from local AsyncStorage cache
  try {
    const json = await AsyncStorage.getItem(key);
    if (json) {
      const existing: StudentQuizResult[] = JSON.parse(json);
      const filtered = existing.filter((r) => {
        const sameStudent = r.studentId === target.studentId || r.studentId === studentId;
        const sameTitle = (r.quizTitle || "").trim().toLowerCase() === normTargetTitle;
        return !(sameStudent && sameTitle);
      });
      await AsyncStorage.setItem(key, JSON.stringify(filtered));
    }
  } catch (err) {
    console.error("Failed to delete student quiz result locally:", err);
  }

  // 2. Remove from Supabase `student_quiz_results`
  try {
    if (process.env.EXPO_PUBLIC_SUPABASE_URL && studentId && classroomId) {
      const { supabase } = await import("../supabase");
      await supabase
        .from("student_quiz_results")
        .delete()
        .eq("student_id", studentId)
        .eq("classroom_id", classroomId)
        .eq("quiz_title", target.quizTitle);
    }
  } catch (cloudErr) {
    console.warn("Could not delete student quiz result from Supabase:", cloudErr);
  }

  // 3. Recalculate cumulative average (or reset to 0 if no assessments remain)
  const recalculated = await recalculateStudentAverage(studentId, classroomId);
  const finalAvg = recalculated >= 0 ? recalculated : 0;
  if (recalculated < 0) {
    try {
      if (process.env.EXPO_PUBLIC_SUPABASE_URL && studentId) {
        const { supabase } = await import("../supabase");
        await supabase.from("students").update({ average: 0 }).eq("id", studentId);
      }
    } catch {
      // ignore offline update error
    }
  }

  const refreshed = await getStudentResults(classroomId, studentId, studentName);
  return { results: refreshed, newAverage: finalAvg };
}

/**
 * Purges all cached quiz results for a permanently removed student from local storage.
 */
export async function deleteAllResultsForStudent(
  classroomId: string,
  studentId: string
): Promise<void> {
  const key = getStorageKey(classroomId);
  try {
    const json = await AsyncStorage.getItem(key);
    if (!json) return;
    const existing: StudentQuizResult[] = JSON.parse(json);
    const remaining = existing.filter((r) => r.studentId !== studentId);
    await AsyncStorage.setItem(key, JSON.stringify(remaining));
  } catch (err) {
    console.warn("Failed to purge local quiz results for removed student:", err);
  }
}

/**
 * Recalculates and updates a student's cumulative average grade in the `students` table
 * based on all their quiz results (merging Supabase `student_quiz_results` and local cache)
 * for the specified classroom. Returns the newly computed average (0-100), or -1 if no records exist.
 */
export async function recalculateStudentAverage(
  studentId: string,
  classroomId: string
): Promise<number> {
  try {
    const scoreByQuiz = new Map<string, number>();

    // 1. Read local AsyncStorage results first (always available immediately after save)
    try {
      const json = await AsyncStorage.getItem(getStorageKey(classroomId));
      if (json) {
        const localAll: StudentQuizResult[] = JSON.parse(json);
        for (const r of localAll) {
          if (r.studentId !== studentId) continue;
          const pct =
            typeof r.scorePercentage === "number" && !Number.isNaN(r.scorePercentage)
              ? r.scorePercentage
              : r.maxScore > 0
                ? (r.totalScore / r.maxScore) * 100
                : null;
          if (pct !== null) {
            scoreByQuiz.set((r.quizTitle || "").trim().toLowerCase(), pct);
          }
        }
      }
    } catch {
      // ignore local parse errors
    }

    // 2. Merge Supabase `student_quiz_results` (cross-device source of truth)
    let supabaseRef: any = null;
    try {
      const mod = await import("../supabase");
      supabaseRef = mod.supabase;
      const { data: allScores, error } = await supabaseRef
        .from("student_quiz_results")
        .select("quiz_title, score_percentage, total_score, max_score")
        .eq("student_id", studentId)
        .eq("classroom_id", classroomId);

      if (!error && Array.isArray(allScores)) {
        for (const s of allScores) {
          const pct =
            typeof s.score_percentage === "number" && !Number.isNaN(s.score_percentage)
              ? s.score_percentage
              : s.max_score && s.max_score > 0
                ? (s.total_score / s.max_score) * 100
                : null;
          if (pct !== null) {
            scoreByQuiz.set(String(s.quiz_title || "").trim().toLowerCase(), pct);
          }
        }
      }
    } catch {
      // offline or table not migrated yet
    }

    if (scoreByQuiz.size === 0) {
      return -1;
    }

    let sumPct = 0;
    for (const pct of scoreByQuiz.values()) {
      sumPct += pct;
    }

    const calculatedAvg = Math.round(sumPct / scoreByQuiz.size);
    if (supabaseRef) {
      await supabaseRef
        .from("students")
        .update({ average: calculatedAvg })
        .eq("id", studentId);
    }
    return calculatedAvg;
  } catch (err) {
    console.warn("Failed to recalculate student average:", err);
  }
  return -1;
}

// ── Load All Results for a Classroom ──────────────────────────────────────────
export async function getAllStudentQuizResults(
  classroomId: string
): Promise<StudentQuizResult[]> {
  const key = getStorageKey(classroomId);
  let localResults: StudentQuizResult[] = [];
  try {
    const json = await AsyncStorage.getItem(key);
    if (json) {
      localResults = JSON.parse(json);
    }
  } catch (err) {
    console.error("Failed to load student quiz results:", err);
  }

  // Attempt to merge from Supabase `student_quiz_results`
  try {
    if (process.env.EXPO_PUBLIC_SUPABASE_URL && classroomId) {
      const { supabase } = await import("../supabase");
      const { data, error } = await supabase
        .from("student_quiz_results")
        .select("*")
        .eq("classroom_id", classroomId)
        .order("graded_at", { ascending: true });

      if (!error && Array.isArray(data) && data.length > 0) {
        const mergedMap = new Map<string, StudentQuizResult>();
        for (const lr of localResults) {
          mergedMap.set(`${lr.studentId}:::${(lr.quizTitle || "").trim().toLowerCase()}`, lr);
        }
        for (const row of data) {
          const k = `${row.student_id}:::${String(row.quiz_title || "").trim().toLowerCase()}`;
          const existing = mergedMap.get(k);
          mergedMap.set(k, {
            studentId: row.student_id,
            studentName: existing?.studentName || "",
            classroomId: row.classroom_id,
            quizId: row.quiz_id || existing?.quizId || null,
            quizTitle: row.quiz_title,
            scorePercentage: Number(row.score_percentage) || 0,
            totalScore: Number(row.total_score) || 0,
            maxScore: Number(row.max_score) || 0,
            results: Array.isArray(row.item_results) ? row.item_results : (existing?.results || []),
            gradedAt: row.graded_at || existing?.gradedAt || new Date().toISOString(),
          });
        }
        const merged = Array.from(mergedMap.values());
        await AsyncStorage.setItem(key, JSON.stringify(merged)).catch(() => {});
        return merged;
      }
    }
  } catch {
    // Ignore cloud fetch errors when offline or table not migrated yet
  }

  return localResults;
}

// ── Get Results for a Specific Student ────────────────────────────────────────
export async function getStudentResults(
  classroomId: string,
  studentId: string,
  studentName?: string
): Promise<StudentQuizResult[]> {
  const all = await getAllStudentQuizResults(classroomId);
  const normName = (studentName || "").trim().toLowerCase();

  const matching = all.filter((r) => {
    if (r.studentId === studentId) return true;
    // Rescue legacy results saved before student UUID matching existed
    if (normName && !isUuidLike(r.studentId)) {
      const legacyIdNorm = (r.studentId || "").trim().toLowerCase();
      const legacyNameNorm = (r.studentName || "").trim().toLowerCase();
      return legacyIdNorm === normName || legacyNameNorm === normName;
    }
    return false;
  });

  // Sort newest recorded assessment first so teachers immediately see latest graded sheets at the top
  return matching.sort(
    (a, b) => new Date(b.gradedAt || 0).getTime() - new Date(a.gradedAt || 0).getTime()
  );
}

// ── Get Results for a Specific Quiz ───────────────────────────────────────────
export async function getQuizResults(
  classroomId: string,
  quizTitle: string
): Promise<StudentQuizResult[]> {
  const all = await getAllStudentQuizResults(classroomId);
  return all.filter((r) => r.quizTitle === quizTitle);
}

// ── Class-Wide Quiz Analysis ──────────────────────────────────────────────────
/**
 * Analyzes all graded results for a specific quiz across the class.
 * Computes per-question difficulty index (p-value), identifies most-missed questions,
 * calculates distractor frequency distribution, and generates pedagogical recommendations.
 */
export async function analyzeQuizForClass(
  classroomId: string,
  quizTitle: string,
  publishedQuiz?: any,
  rosterStudents?: { id: string; full_name: string }[]
): Promise<ClassQuizAnalysis | null> {
  const quizResults = await getQuizResults(classroomId, quizTitle);
  
  if (quizResults.length === 0) {
    return null;
  }

  // Build per-question aggregates
  const questionMap = new Map<number, {
    questionNumber: number;
    questionText?: string;
    questionType?: string;
    correctAnswer: string;
    options?: string[];
    totalAttempts: number;
    correctCount: number;
    incorrectCount: number;
    distractorCounts: Record<string, number>;
    studentsMissed: string[];
    studentsMissedDetails: StudentMissedDetail[];
    studentsCorrect: string[];
  }>();

  // If a published quiz definition is available, pre-populate question metadata
  if (publishedQuiz && Array.isArray(publishedQuiz.questions)) {
    for (const q of publishedQuiz.questions) {
      const qNum = q.questionNumber || q.id;
      const keyItem = Array.isArray(publishedQuiz.answerKey)
        ? publishedQuiz.answerKey.find((k: any) => (k.questionNumber || k.qNum) === qNum)
        : null;
      const ans = keyItem?.correctAnswer || q.correctAnswer || "";

      questionMap.set(qNum, {
        questionNumber: qNum,
        questionText: q.questionText || q.question,
        questionType: q.type || q.questionType || "multiple_choice",
        correctAnswer: String(ans || "").trim().toUpperCase(),
        options: Array.isArray(q.options) ? q.options : ["A", "B", "C", "D"],
        totalAttempts: 0,
        correctCount: 0,
        incorrectCount: 0,
        distractorCounts: {},
        studentsMissed: [],
        studentsMissedDetails: [],
        studentsCorrect: [],
      });
    }
  }

  for (const studentResult of quizResults) {
    const rawName = (studentResult.studentName || "").trim();
    const matchedRoster = rosterStudents?.find((s) => s.id === studentResult.studentId);
    const resolvedStudentName = rawName || matchedRoster?.full_name?.trim() || "";

    for (const qr of studentResult.results) {
      const qNum = qr.questionNumber;
      let existing = questionMap.get(qNum);
      const studentAns = String(qr.studentAnswer || "BLANK").trim().toUpperCase();

      if (!existing) {
        const keyItem = Array.isArray(publishedQuiz?.answerKey)
          ? publishedQuiz.answerKey.find((k: any) => (k.questionNumber || k.qNum) === qNum)
          : null;
        const ans = keyItem?.correctAnswer || qr.correctAnswer || "";

        existing = {
          questionNumber: qNum,
          questionText: qr.questionText,
          questionType: qr.questionType,
          correctAnswer: String(ans || "").trim().toUpperCase(),
          options: ["A", "B", "C", "D"],
          totalAttempts: 0,
          correctCount: 0,
          incorrectCount: 0,
          distractorCounts: {},
          studentsMissed: [],
          studentsMissedDetails: [],
          studentsCorrect: [],
        };
        questionMap.set(qNum, existing);
      } else if (!existing.correctAnswer && qr.correctAnswer) {
        existing.correctAnswer = String(qr.correctAnswer).trim().toUpperCase();
      }

      existing.totalAttempts++;
      existing.distractorCounts[studentAns] = (existing.distractorCounts[studentAns] || 0) + 1;

      if (qr.isCorrect) {
        existing.correctCount++;
        if (resolvedStudentName) {
          existing.studentsCorrect.push(resolvedStudentName);
        }
      } else {
        existing.incorrectCount++;
        if (resolvedStudentName) {
          existing.studentsMissed.push(resolvedStudentName);
          existing.studentsMissedDetails.push({
            studentId: studentResult.studentId,
            studentName: resolvedStudentName,
            studentAnswer: qr.studentAnswer || "Blank",
          });
        }
      }
    }
  }

  const allQuestions: QuestionAnalysisSummary[] = Array.from(questionMap.values())
    .filter((q) => q.totalAttempts > 0)
    .map((raw) => {
      const accuracyRate = raw.totalAttempts > 0 ? Math.round((raw.correctCount / raw.totalAttempts) * 100) : 0;
      const missedRate = 100 - accuracyRate;
      const difficultyIndex = raw.totalAttempts > 0 ? Math.round((raw.correctCount / raw.totalAttempts) * 100) / 100 : 0.50;
      const difficultyLevel = getDifficultyLevel(difficultyIndex);

      // Distractor Breakdown
      const standardOptions = raw.options && raw.options.length > 0 ? raw.options : ["A", "B", "C", "D"];
      const distractorBreakdown: DistractorOptionStat[] = standardOptions.map((opt) => {
        const optLetter = opt.length === 1 ? opt.toUpperCase() : opt.charAt(0).toUpperCase();
        const count = raw.distractorCounts[optLetter] || raw.distractorCounts[opt] || 0;
        const percentage = raw.totalAttempts > 0 ? Math.round((count / raw.totalAttempts) * 100) : 0;
        const isCorrect = optLetter === raw.correctAnswer || opt === raw.correctAnswer;
        return {
          option: optLetter,
          count,
          percentage,
          isCorrect,
        };
      });

      // Find Most Common Mistake
      let mostCommonMistake: { answer: string; count: number; percentage: number } | undefined;
      for (const [ans, count] of Object.entries(raw.distractorCounts)) {
        if (ans !== raw.correctAnswer && count > 0) {
          if (!mostCommonMistake || count > mostCommonMistake.count) {
            mostCommonMistake = {
              answer: ans,
              count,
              percentage: raw.totalAttempts > 0 ? Math.round((count / raw.totalAttempts) * 100) : 0,
            };
          }
        }
      }

      // Pedagogical Insight
      let pedagogicalInsight = "";
      if (difficultyLevel === "Difficult") {
        pedagogicalInsight = `${missedRate}% of students missed this question. ${
          mostCommonMistake
            ? `Most common misconception was option [${mostCommonMistake.answer}] (${mostCommonMistake.percentage}% chose this). `
            : ""
        }Targeted concept re-teaching recommended.`;
      } else if (difficultyLevel === "Moderate") {
        pedagogicalInsight = `Balanced discriminator (p = ${difficultyIndex}). ${accuracyRate}% demonstrated mastery, while ${missedRate}% need brief reinforcement.`;
      } else {
        pedagogicalInsight = `High mastery item (p = ${difficultyIndex}). ${accuracyRate}% answered correctly. Excellent retention.`;
      }

      return {
        questionNumber: raw.questionNumber,
        questionText: raw.questionText,
        questionType: raw.questionType,
        correctAnswer: raw.correctAnswer,
        options: raw.options,
        totalAttempts: raw.totalAttempts,
        correctCount: raw.correctCount,
        incorrectCount: raw.incorrectCount,
        accuracyRate,
        missedRate,
        difficultyIndex,
        difficultyLevel,
        distractorCounts: raw.distractorCounts,
        distractorBreakdown,
        mostCommonMistake,
        pedagogicalInsight,
        studentsMissed: raw.studentsMissed,
        studentsMissedDetails: raw.studentsMissedDetails,
        studentsCorrect: raw.studentsCorrect,
      };
    })
    .sort((a, b) => a.questionNumber - b.questionNumber);

  // Sort by highest miss rate / lowest difficulty index to find most missed questions
  const mostMissedQuestions = [...allQuestions].sort(
    (a, b) => b.missedRate - a.missedRate || a.difficultyIndex - b.difficultyIndex
  );
  const hardestQuestions = mostMissedQuestions.slice(0, 3);
  const easiestQuestions = [...allQuestions].sort(
    (a, b) => b.accuracyRate - a.accuracyRate || b.difficultyIndex - a.difficultyIndex
  ).slice(0, 3);

  const totalGraded = quizResults.length;
  const classAverageScore = Math.round(
    quizResults.reduce((sum, r) => sum + r.scorePercentage, 0) / (totalGraded || 1)
  );

  const avgDiff = allQuestions.length > 0
    ? Math.round((allQuestions.reduce((sum, q) => sum + q.difficultyIndex, 0) / allQuestions.length) * 100) / 100
    : 0.50;

  const easyCount = allQuestions.filter((q) => q.difficultyLevel === "Easy").length;
  const moderateCount = allQuestions.filter((q) => q.difficultyLevel === "Moderate").length;
  const difficultCount = allQuestions.filter((q) => q.difficultyLevel === "Difficult").length;

  let overallRecommendation = "";
  if (difficultCount >= 3) {
    overallRecommendation = `Found ${difficultCount} difficult items. We recommend reviewing Questions ${mostMissedQuestions.slice(0, 2).map((q) => `Q${q.questionNumber}`).join(" & ")} during the next class session.`;
  } else if (easyCount >= allQuestions.length * 0.7) {
    overallRecommendation = `Class demonstrated high facility across most items. Consider introducing higher-order Bloom's taxonomy application problems.`;
  } else {
    overallRecommendation = `Well-balanced assessment difficulty. Moderate questions effectively discriminated student performance across the class.`;
  }

  return {
    quizTitle,
    totalStudentsGraded: totalGraded,
    classAverageScore,
    averageDifficultyIndex: avgDiff,
    difficultyBreakdown: {
      easyCount,
      moderateCount,
      difficultCount,
    },
    questionBreakdown: allQuestions,
    mostMissedQuestions,
    hardestQuestions,
    easiestQuestions,
    overallRecommendation,
  };
}

/**
 * Generates an authentic, realistic Item Analysis benchmark for preview or zero-data testing.
 * Uses real student names from the classroom roster and aligns with published quiz questions.
 */
export function generateDemoQuizAnalysis(
  quizTitle: string,
  classroomTitle?: string,
  rosterStudents?: { id: string; full_name: string }[],
  publishedQuiz?: any
): ClassQuizAnalysis {
  const defaultNames = [
    "Sarah Jenkins",
    "Michael Chang",
    "Emily Davis",
    "Liam Vance",
    "Sophia Reyes",
    "Lucas Wright",
    "Olivia Chen",
    "Noah Miller",
    "Mia Santos",
  ];

  const studentPool = rosterStudents && rosterStudents.length >= 3
    ? rosterStudents.map((s) => s.full_name)
    : defaultNames;

  const totalStudents = studentPool.length;

  // Realistic question blueprints
  const defaultItems = [
    {
      qNum: 1,
      text: "Which cellular organelle is responsible for ATP synthesis via aerobic respiration?",
      key: "A",
      type: "multiple_choice",
      options: ["A", "B", "C", "D"],
      accuracy: 89, // Easy (p = 0.89)
      misconceptions: { A: 8, B: 1, C: 0, D: 0 },
    },
    {
      qNum: 2,
      text: "What is the primary role of messenger RNA (mRNA) in protein biosynthesis?",
      key: "B",
      type: "multiple_choice",
      options: ["A", "B", "C", "D"],
      accuracy: 67, // Moderate (p = 0.67)
      misconceptions: { A: 1, B: 6, C: 2, D: 0 },
    },
    {
      qNum: 3,
      text: "During enzyme catalysis, how does the presence of an active enzyme affect activation energy?",
      key: "C",
      type: "multiple_choice",
      options: ["A", "B", "C", "D"],
      accuracy: 78, // Easy (p = 0.78)
      misconceptions: { A: 1, B: 1, C: 7, D: 0 },
    },
    {
      qNum: 4,
      text: "During which phase of mitosis do sister chromatids segregate and migrate to opposite poles?",
      key: "A",
      type: "multiple_choice",
      options: ["A", "B", "C", "D"],
      accuracy: 22, // Difficult (p = 0.22) - Top Most Missed!
      misconceptions: { A: 2, B: 6, C: 1, D: 0 }, // 6 students picked B (Metaphase)
    },
    {
      qNum: 5,
      text: "Which lipid bilayer property is maintained by cholesterol molecules at low temperatures?",
      key: "D",
      type: "multiple_choice",
      options: ["A", "B", "C", "D"],
      accuracy: 56, // Moderate (p = 0.56)
      misconceptions: { A: 1, B: 2, C: 1, D: 5 },
    },
    {
      qNum: 6,
      text: "In anaerobic fermentation in human muscle cells, what is pyruvate converted into?",
      key: "B",
      type: "multiple_choice",
      options: ["A", "B", "C", "D"],
      accuracy: 67, // Moderate (p = 0.67)
      misconceptions: { A: 1, B: 6, C: 1, D: 1 },
    },
    {
      qNum: 7,
      text: "Which law of thermodynamics states that total entropy of an isolated system always increases?",
      key: "C",
      type: "multiple_choice",
      options: ["A", "B", "C", "D"],
      accuracy: 33, // Difficult (p = 0.33) - 2nd Most Missed!
      misconceptions: { A: 4, B: 2, C: 3, D: 0 }, // 4 students picked A (First law)
    },
    {
      qNum: 8,
      text: "What type of cellular junction provides tight cytoplasmic bridges between adjacent plant cells?",
      key: "A",
      type: "multiple_choice",
      options: ["A", "B", "C", "D"],
      accuracy: 78, // Easy (p = 0.78)
      misconceptions: { A: 7, B: 1, C: 1, D: 0 },
    },
    {
      qNum: 9,
      text: "Which metabolic cycle occurs in the mitochondrial matrix to generate NADH and FADH2?",
      key: "D",
      type: "multiple_choice",
      options: ["A", "B", "C", "D"],
      accuracy: 56, // Moderate (p = 0.56)
      misconceptions: { A: 1, B: 2, C: 1, D: 5 },
    },
    {
      qNum: 10,
      text: "Which organelle contains hydrolytic digestive enzymes for autolysis and waste degradation?",
      key: "B",
      type: "multiple_choice",
      options: ["A", "B", "C", "D"],
      accuracy: 89, // Easy (p = 0.89)
      misconceptions: { A: 0, B: 8, C: 1, D: 0 },
    },
  ];

  // If published quiz has questions, use its actual questions & keys
  const itemsToUse = publishedQuiz && Array.isArray(publishedQuiz.questions) && publishedQuiz.questions.length > 0
    ? publishedQuiz.questions.map((q: any, idx: number) => {
        const fallback = defaultItems[idx % defaultItems.length];
        const keyItem = Array.isArray(publishedQuiz.answerKey)
          ? publishedQuiz.answerKey.find((k: any) => (k.questionNumber || k.qNum) === (q.questionNumber || idx + 1))
          : null;
        const resolvedKey = keyItem?.correctAnswer || q.correctAnswer || fallback.key;
        return {
          qNum: q.questionNumber || (idx + 1),
          text: q.questionText || q.question || fallback.text,
          key: String(resolvedKey || fallback.key).trim().toUpperCase(),
          type: q.type || fallback.type,
          options: Array.isArray(q.options) && q.options.length > 0 ? q.options : fallback.options,
          accuracy: fallback.accuracy,
          misconceptions: fallback.misconceptions,
        };
      })
    : defaultItems;

  const questionBreakdown: QuestionAnalysisSummary[] = itemsToUse.map((item: any) => {
    const correctCount = Math.max(1, Math.round((item.accuracy / 100) * totalStudents));
    const incorrectCount = totalStudents - correctCount;
    const accuracyRate = Math.round((correctCount / totalStudents) * 100);
    const missedRate = 100 - accuracyRate;
    const difficultyIndex = Math.round((correctCount / totalStudents) * 100) / 100;
    const difficultyLevel = getDifficultyLevel(difficultyIndex);

    // Distribute students
    const studentsCorrect = studentPool.slice(0, correctCount);
    const studentsMissed = studentPool.slice(correctCount);

    const distractorCounts: Record<string, number> = {
      [item.key]: correctCount,
    };

    // Allocate incorrect answers across options
    const otherOptions = ["A", "B", "C", "D"].filter((o) => o !== item.key);
    const primaryDistractor = item.qNum === 4 ? "B" : item.qNum === 7 ? "A" : otherOptions[0];
    const secondaryDistractor = otherOptions.find((o) => o !== primaryDistractor) || otherOptions[1];

    const primaryCount = Math.ceil(incorrectCount * 0.7);
    const secondaryCount = incorrectCount - primaryCount;

    if (primaryCount > 0) distractorCounts[primaryDistractor] = primaryCount;
    if (secondaryCount > 0) distractorCounts[secondaryDistractor] = secondaryCount;

    const distractorBreakdown: DistractorOptionStat[] = ["A", "B", "C", "D"].map((opt) => {
      const count = distractorCounts[opt] || 0;
      return {
        option: opt,
        count,
        percentage: Math.round((count / totalStudents) * 100),
        isCorrect: opt === item.key,
      };
    });

    const mostCommonMistake = incorrectCount > 0 ? {
      answer: primaryDistractor,
      count: primaryCount,
      percentage: Math.round((primaryCount / totalStudents) * 100),
    } : undefined;

    const studentsMissedDetails: StudentMissedDetail[] = studentsMissed.map((name, i) => ({
      studentId: `stud-${i}`,
      studentName: name,
      studentAnswer: i < primaryCount ? primaryDistractor : secondaryDistractor,
    }));

    let pedagogicalInsight = "";
    if (difficultyLevel === "Difficult") {
      pedagogicalInsight = `${missedRate}% of students missed this item. ${
        mostCommonMistake
          ? `Widespread misconception: ${mostCommonMistake.percentage}% chose distractor [${mostCommonMistake.answer}]. `
          : ""
      }Reviewing this concept with targeted practice is strongly recommended.`;
    } else if (difficultyLevel === "Moderate") {
      pedagogicalInsight = `Optimal discriminator (p = ${difficultyIndex}). ${accuracyRate}% demonstrated mastery, while ${missedRate}% need brief reinforcement.`;
    } else {
      pedagogicalInsight = `High mastery item (p = ${difficultyIndex}). ${accuracyRate}% class accuracy. Core concept well understood.`;
    }

    return {
      questionNumber: item.qNum,
      questionText: item.text,
      questionType: item.type,
      correctAnswer: item.key,
      options: item.options,
      totalAttempts: totalStudents,
      correctCount,
      incorrectCount,
      accuracyRate,
      missedRate,
      difficultyIndex,
      difficultyLevel,
      distractorCounts,
      distractorBreakdown,
      mostCommonMistake,
      pedagogicalInsight,
      studentsMissed,
      studentsMissedDetails,
      studentsCorrect,
    };
  });

  const mostMissedQuestions = [...questionBreakdown].sort(
    (a, b) => b.missedRate - a.missedRate || a.difficultyIndex - b.difficultyIndex
  );
  const hardestQuestions = mostMissedQuestions.slice(0, 3);
  const easiestQuestions = [...questionBreakdown].sort(
    (a, b) => b.accuracyRate - a.accuracyRate || b.difficultyIndex - a.difficultyIndex
  ).slice(0, 3);

  const avgDiff = Math.round((questionBreakdown.reduce((sum, q) => sum + q.difficultyIndex, 0) / questionBreakdown.length) * 100) / 100;
  const classAverageScore = Math.round(avgDiff * 100);

  const easyCount = questionBreakdown.filter((q) => q.difficultyLevel === "Easy").length;
  const moderateCount = questionBreakdown.filter((q) => q.difficultyLevel === "Moderate").length;
  const difficultCount = questionBreakdown.filter((q) => q.difficultyLevel === "Difficult").length;

  return {
    quizTitle: quizTitle || "Classroom Assessment",
    totalStudentsGraded: totalStudents,
    classAverageScore,
    averageDifficultyIndex: avgDiff,
    difficultyBreakdown: {
      easyCount,
      moderateCount,
      difficultCount,
    },
    questionBreakdown,
    mostMissedQuestions,
    hardestQuestions,
    easiestQuestions,
    overallRecommendation: `Item Analysis flagged ${difficultCount} questions needing review (Q4 & Q7). 67% of missed answers on Q4 selected distractor [B]. Consider re-teaching Mitosis phases before the next unit test.`,
  };
}

// ── Get Student's Weak Areas Across All Quizzes ───────────────────────────────
/**
 * Analyzes a student's question-level results to determine topic areas of weakness.
 * Returns the question types and specific questions the student struggles with.
 */
export function analyzeStudentWeakAreas(
  studentResults: StudentQuizResult[]
): {
  totalQuestionsAttempted: number;
  totalCorrect: number;
  overallAccuracy: number;
  weakQuestionTypes: { type: string; accuracy: number; missed: number; total: number }[];
  recentMissedQuestions: { quizTitle: string; questionNumber: number; questionText?: string; correctAnswer: string }[];
  trend: "improving" | "declining" | "stable" | "insufficient_data";
} {
  if (studentResults.length === 0) {
    return {
      totalQuestionsAttempted: 0,
      totalCorrect: 0,
      overallAccuracy: 0,
      weakQuestionTypes: [],
      recentMissedQuestions: [],
      trend: "insufficient_data",
    };
  }

  let totalAttempted = 0;
  let totalCorrect = 0;

  // Aggregate by question type
  const typeMap = new Map<string, { correct: number; total: number }>();

  // Track recently missed questions (from all quizzes)
  const recentMissed: {
    quizTitle: string;
    questionNumber: number;
    questionText?: string;
    correctAnswer: string;
  }[] = [];

  for (const quiz of studentResults) {
    for (const qr of quiz.results) {
      totalAttempted++;
      if (qr.isCorrect) totalCorrect++;

      const qType = qr.questionType || "unknown";
      const existing = typeMap.get(qType) || { correct: 0, total: 0 };
      existing.total++;
      if (qr.isCorrect) existing.correct++;
      typeMap.set(qType, existing);

      if (!qr.isCorrect) {
        recentMissed.push({
          quizTitle: quiz.quizTitle,
          questionNumber: qr.questionNumber,
          questionText: qr.questionText,
          correctAnswer: qr.correctAnswer,
        });
      }
    }
  }

  // Determine weak question types (accuracy below 60%)
  const weakQuestionTypes = Array.from(typeMap.entries())
    .map(([type, stats]) => ({
      type,
      accuracy: Math.round((stats.correct / stats.total) * 100),
      missed: stats.total - stats.correct,
      total: stats.total,
    }))
    .filter((t) => t.accuracy < 60)
    .sort((a, b) => a.accuracy - b.accuracy);

  // Determine trend from quiz scores over time
  let trend: "improving" | "declining" | "stable" | "insufficient_data" =
    "insufficient_data";
  if (studentResults.length >= 2) {
    const sorted = [...studentResults].sort(
      (a, b) =>
        new Date(a.gradedAt).getTime() - new Date(b.gradedAt).getTime()
    );
    const recentScores = sorted.slice(-3).map((r) => r.scorePercentage);
    if (recentScores.length >= 2) {
      const first = recentScores[0];
      const last = recentScores[recentScores.length - 1];
      const diff = last - first;
      if (diff > 5) trend = "improving";
      else if (diff < -5) trend = "declining";
      else trend = "stable";
    }
  }

  return {
    totalQuestionsAttempted: totalAttempted,
    totalCorrect,
    overallAccuracy: totalAttempted > 0
      ? Math.round((totalCorrect / totalAttempted) * 100)
      : 0,
    weakQuestionTypes,
    recentMissedQuestions: recentMissed.slice(-5), // Last 5 missed
    trend,
  };
}

// ── Delete Results for a Classroom ────────────────────────────────────────────
export async function deleteClassroomQuizResults(
  classroomId: string
): Promise<void> {
  const key = getStorageKey(classroomId);
  try {
    await AsyncStorage.removeItem(key);
  } catch (err) {
    console.error("Failed to delete classroom quiz results:", err);
  }
}
