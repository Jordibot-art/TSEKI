import React, { useState, useRef, useEffect } from "react";
import {
    Modal,
    View,
    Text,
    StyleSheet,
    TouchableOpacity,
    TouchableWithoutFeedback,
    Dimensions,
    Image,
    ScrollView,
    ActivityIndicator,
    Animated,
    Easing,
    Pressable,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { CameraView, useCameraPermissions } from "expo-camera";
import * as Haptics from "expo-haptics";
import * as ImagePicker from "expo-image-picker";
import { useTheme } from "../context/ThemeContext";
import { BatchSheetItem } from "../lib/batchGradingQueue";
import { AUTO_DETECT_ASSESSMENT, matchAssessmentByQr } from "../lib/assessmentDetector";
import type { StoredQuiz } from "../lib/quizStore";
import { PhotoGuidanceModal } from "./PhotoGuidanceModal";
import {
    getSemanticTokens,
    getSkeuoPalette,
    skeuoButtonStyle,
    triggerSkeuoHaptic,
} from "./skeuoTheme";
import {
    cropCapturedSheetToReticle,
    evaluateLiveHoverQuality,
    LiveHoverDiagnostics,
    QrLiveObservation,
} from "../lib/liveCameraInspector";

const { width: SCREEN_WIDTH, height: SCREEN_HEIGHT } = Dimensions.get("window");
const RETICLE_WIDTH = SCREEN_WIDTH * 0.88;
const RETICLE_HEIGHT = Math.min(SCREEN_WIDTH * 0.88 * 1.30, SCREEN_HEIGHT * 0.54);

export interface BatchScannerModalProps {
    visible: boolean;
    onClose: () => void;
    onCaptureSheet: (uri: string, qrData?: string | null) => void;
    onBatchImportSheets: (uris: string[]) => void;
    onFinishAndReview: () => void;
    onRemoveSheet?: (id: string) => void;
    items?: BatchSheetItem[];
    quizTitle: string;
    publishedQuizzes?: StoredQuiz[];
    classTitle: string;
    accentColor?: string;
    mode?: "single" | "batch";
    onCaptureSingleSheet?: (uri: string, qrData?: string | null) => void;
}

export function BatchScannerModal({
    visible,
    onClose,
    onCaptureSheet,
    onBatchImportSheets,
    onFinishAndReview,
    onRemoveSheet,
    items = [],
    quizTitle,
    publishedQuizzes = [],
    classTitle,
    accentColor = "#F97316",
    mode = "batch",
    onCaptureSingleSheet,
}: BatchScannerModalProps) {
    const { darkMode } = useTheme();
    const [permission, requestPermission] = useCameraPermissions();
    const cameraRef = useRef<any>(null);
    const [flashMode, setFlashMode] = useState<"off" | "on">("off");
    const [isCapturing, setIsCapturing] = useState<boolean>(false);
    const [recentThumbnails, setRecentThumbnails] = useState<string[]>([]);
    const [guidanceOpen, setGuidanceOpen] = useState<boolean>(false);

    // Live QR visibility detection in camera frame
    const [qrDetectedLive, setQrDetectedLive] = useState<boolean>(false);
    const qrTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
    const qrObsRef = useRef<QrLiveObservation>({
        detected: false,
        lastSeenMs: 0,
    });

    // Real-time hover diagnostics (updated continuously from live barcode scanner without background photo captures)
    const [cameraReady, setCameraReady] = useState<boolean>(false);
    const [liveHoverStatus, setLiveHoverStatus] = useState<LiveHoverDiagnostics | null>(null);

    // Motion blur detection, live QR assessment match & Tap-to-Focus
    const lastQrDataRef = useRef<string | null>(null);
    const [liveDetectedQuizTitle, setLiveDetectedQuizTitle] = useState<string | null>(null);
    const lastCenterRef = useRef<{ x: number; y: number; time: number } | null>(null);
    const blurTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
    const [focusPoint, setFocusPoint] = useState<{ x: number; y: number } | null>(null);
    const focusAnim = useRef(new Animated.Value(0)).current;

    const handleTouchToFocus = (e: any) => {
        const { pageX, pageY } = e.nativeEvent;
        setFocusPoint({ x: pageX, y: pageY });
        focusAnim.setValue(0);
        Animated.sequence([
            Animated.timing(focusAnim, {
                toValue: 1,
                duration: 250,
                useNativeDriver: true,
            }),
            Animated.delay(450),
            Animated.timing(focusAnim, {
                toValue: 0,
                duration: 250,
                useNativeDriver: true,
            }),
        ]).start(() => setFocusPoint(null));

        try {
            Haptics.selectionAsync();
        } catch {}

        if (blurTimerRef.current) clearTimeout(blurTimerRef.current);
        blurTimerRef.current = setTimeout(() => {
            qrObsRef.current = {
                ...qrObsRef.current,
                isBlurry: false,
            };
            const settled = evaluateLiveHoverQuality(null, qrObsRef.current, Date.now());
            setLiveHoverStatus(settled);
        }, 320);
    };

    // Active Photo Quality Alert inside camera (for Batch Mode background grading)
    const [activeQualityAlert, setActiveQualityAlert] = useState<{
        itemId?: string;
        studentLabel: string;
        warnings: string[];
    } | null>(null);
    const alertedItemIdsRef = useRef<Set<string>>(new Set());

    // Shutter flash animation (only fires when user taps the camera shutter button)
    const flashAnim = useRef(new Animated.Value(0)).current;

    // Viewfinder Scanning Laser Beam and Corner Pulse Animations
    const scanLaserAnim = useRef(new Animated.Value(0)).current;
    const cornerPulseAnim = useRef(new Animated.Value(1)).current;

    useEffect(() => {
        let laserLoop: Animated.CompositeAnimation | null = null;
        let cornerLoop: Animated.CompositeAnimation | null = null;

        if (visible) {
            scanLaserAnim.setValue(0);
            cornerPulseAnim.setValue(1);

            laserLoop = Animated.loop(
                Animated.sequence([
                    Animated.timing(scanLaserAnim, {
                        toValue: 1,
                        duration: 2200,
                        easing: Easing.inOut(Easing.quad),
                        useNativeDriver: true,
                    }),
                    Animated.timing(scanLaserAnim, {
                        toValue: 0,
                        duration: 2200,
                        easing: Easing.inOut(Easing.quad),
                        useNativeDriver: true,
                    }),
                ])
            );

            cornerLoop = Animated.loop(
                Animated.sequence([
                    Animated.timing(cornerPulseAnim, {
                        toValue: 1.05,
                        duration: 1100,
                        easing: Easing.inOut(Easing.ease),
                        useNativeDriver: true,
                    }),
                    Animated.timing(cornerPulseAnim, {
                        toValue: 1.0,
                        duration: 1100,
                        easing: Easing.inOut(Easing.ease),
                        useNativeDriver: true,
                    }),
                ])
            );

            laserLoop.start();
            cornerLoop.start();
        } else {
            scanLaserAnim.setValue(0);
            cornerPulseAnim.setValue(1);
        }

        return () => {
            laserLoop?.stop();
            cornerLoop?.stop();
        };
    }, [visible]);

    const isSingle = mode === "single";
    const totalCaptured = items.length;
    const completedCount = items.filter((i) => i.status === "ready" || i.status === "needs_review").length;
    const flaggedCount = items.filter((i) => i.status === "needs_review").length;
    const inProgressCount = items.filter((i) => i.status === "queued" || i.status === "optimizing" || i.status === "grading").length;

    useEffect(() => {
        if (visible && (!permission || !permission.granted)) {
            requestPermission();
        }
        if (visible && permission?.granted) {
            // Initialize live hover status immediately
            const initDiag = evaluateLiveHoverQuality(null, qrObsRef.current, Date.now());
            setLiveHoverStatus(initDiag);
        }
        if (!visible) {
            setCameraReady(false);
            setQrDetectedLive(false);
            setLiveHoverStatus(null);
            setActiveQualityAlert(null);
            setLiveDetectedQuizTitle(null);
            lastQrDataRef.current = null;
            qrObsRef.current = { detected: false, lastSeenMs: 0 };
            if (qrTimerRef.current) {
                clearTimeout(qrTimerRef.current);
                qrTimerRef.current = null;
            }
            if (blurTimerRef.current) {
                clearTimeout(blurTimerRef.current);
                blurTimerRef.current = null;
            }
            lastCenterRef.current = null;
            setFocusPoint(null);
        }
    }, [visible, permission]);

    // Watch batch items for newly graded sheets that have flagged answers (scribbles/low confidence) or photoQuality warnings
    useEffect(() => {
        if (isSingle || !visible) return;
        for (let idx = items.length - 1; idx >= 0; idx--) {
            const item = items[idx];
            const hasReviewIssue = Boolean(
                (item.flaggedCount && item.flaggedCount > 0) ||
                (item.photoQuality?.hasWarnings && item.photoQuality.warnings.length > 0)
            );
            if (hasReviewIssue && !alertedItemIdsRef.current.has(item.id)) {
                alertedItemIdsRef.current.add(item.id);
                const sheetNumber = idx + 1;
                const label =
                    item.matchedStudentName ||
                    item.studentNameExtracted ||
                    `Sheet #${sheetNumber}`;
                const combinedWarnings: string[] = [
                    ...(item.flaggedCount && item.flaggedCount > 0
                        ? [`${item.flaggedCount} answer(s) have scribbled, overwritten, or low-confidence marks`]
                        : []),
                    ...(item.photoQuality?.warnings || []),
                ];
                setActiveQualityAlert({
                    itemId: item.id,
                    studentLabel: `Sheet #${sheetNumber} (${label})`,
                    warnings: combinedWarnings,
                });
                try {
                    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
                } catch {}
                break;
            }
        }
    }, [items, isSingle, visible]);

    const handleBarcodeScanned = (result: any) => {
        if (result?.data) {
            const now = Date.now();
            let boundsNorm: QrLiveObservation["boundsNorm"] = undefined;
            let isBlurry = false;

            if (result.bounds?.origin && result.bounds?.size && SCREEN_WIDTH > 0 && SCREEN_HEIGHT > 0) {
                boundsNorm = {
                    x: result.bounds.origin.x / SCREEN_WIDTH,
                    y: result.bounds.origin.y / SCREEN_HEIGHT,
                    width: result.bounds.size.width / SCREEN_WIDTH,
                    height: result.bounds.size.height / SCREEN_HEIGHT,
                };

                const cx = boundsNorm.x + boundsNorm.width / 2;
                const cy = boundsNorm.y + boundsNorm.height / 2;

                if (lastCenterRef.current) {
                    const dt = Math.max(16, now - lastCenterRef.current.time);
                    const dist = Math.hypot(cx - lastCenterRef.current.x, cy - lastCenterRef.current.y);
                    // Velocity across screen: if moving faster than 0.35 screen units per second, motion blur degrades text
                    const velocity = dist / (dt / 1000);
                    if (velocity > 0.35 && dt < 450) {
                        isBlurry = true;
                    }
                }
                lastCenterRef.current = { x: cx, y: cy, time: now };
            }

            qrObsRef.current = {
                detected: true,
                lastSeenMs: now,
                boundsNorm,
                cornerPoints: Array.isArray(result.cornerPoints) ? result.cornerPoints : undefined,
                isBlurry,
            };

            if (lastQrDataRef.current && lastQrDataRef.current !== result.data) {
                // Instantly reset position & blur tracking when switching between different papers
                lastCenterRef.current = null;
            }
            lastQrDataRef.current = result.data;
            if (publishedQuizzes.length > 0) {
                const liveMatch = matchAssessmentByQr(result.data, publishedQuizzes);
                setLiveDetectedQuizTitle(liveMatch ? liveMatch.quiz.quizTitle : null);
            }

            setQrDetectedLive(true);
            const diag = evaluateLiveHoverQuality(null, qrObsRef.current, now);
            setLiveHoverStatus(diag);

            if (blurTimerRef.current) {
                clearTimeout(blurTimerRef.current);
            }
            if (isBlurry) {
                // Settle focus after user holds camera steady for 320ms
                blurTimerRef.current = setTimeout(() => {
                    qrObsRef.current = {
                        ...qrObsRef.current,
                        isBlurry: false,
                    };
                    const settled = evaluateLiveHoverQuality(null, qrObsRef.current, Date.now());
                    setLiveHoverStatus(settled);
                }, 320);
            }

            if (qrTimerRef.current) {
                clearTimeout(qrTimerRef.current);
            }
            // Fast 400ms reset when moving away from a paper so markers & QR don't linger for 3 seconds
            qrTimerRef.current = setTimeout(() => {
                lastQrDataRef.current = null;
                lastCenterRef.current = null;
                setLiveDetectedQuizTitle(null);
                qrObsRef.current = {
                    detected: false,
                    lastSeenMs: 0,
                    isBlurry: false,
                };
                setQrDetectedLive(false);
                const expiredDiag = evaluateLiveHoverQuality(null, qrObsRef.current, Date.now());
                setLiveHoverStatus(expiredDiag);
            }, 400);
        }
    };

    // Keep track of the last few captured thumbnail URIs (in batch mode)
    useEffect(() => {
        if (!isSingle) {
            const uris = items.slice(-5).map((i) => i.imageUri).reverse();
            setRecentThumbnails(uris);
        }
    }, [items, isSingle]);

    const triggerShutterFlash = () => {
        flashAnim.setValue(1);
        Animated.timing(flashAnim, {
            toValue: 0,
            duration: 150,
            useNativeDriver: true,
        }).start();
    };

    const handleSnap = async () => {
        if (!cameraRef.current || isCapturing) return;
        setIsCapturing(true);

        try {
            triggerShutterFlash();
            try {
                await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
            } catch (hErr) {
                // Ignore haptics error on web/simulator
            }

            const photo = await cameraRef.current.takePictureAsync({
                quality: 0.9,
                base64: false,
            });

            if (photo && photo.uri) {
                const capturedQrData = lastQrDataRef.current;
                // Auto-crop the raw sensor image to the exact on-screen reticle that the teacher framed,
                // trimming away surrounding laptop keyboard, desk, and legs so the test sheet fills the photo.
                const cropped = await cropCapturedSheetToReticle(photo, SCREEN_WIDTH, SCREEN_HEIGHT);
                const finalUri = cropped.uri;

                if (isSingle) {
                    if (onCaptureSingleSheet) {
                        onCaptureSingleSheet(finalUri, capturedQrData);
                    } else {
                        onCaptureSheet(finalUri, capturedQrData);
                    }
                    onClose();
                } else {
                    onCaptureSheet(finalUri, capturedQrData);
                    // Instantly reset live hover diagnostics for the next sheet!
                    lastQrDataRef.current = null;
                    lastCenterRef.current = null;
                    setLiveDetectedQuizTitle(null);
                    qrObsRef.current = {
                        detected: false,
                        lastSeenMs: 0,
                        isBlurry: false,
                    };
                    setQrDetectedLive(false);
                    if (qrTimerRef.current) clearTimeout(qrTimerRef.current);
                    if (blurTimerRef.current) clearTimeout(blurTimerRef.current);
                    const resetDiag = evaluateLiveHoverQuality(null, qrObsRef.current, Date.now());
                    setLiveHoverStatus(resetDiag);
                }
            }
        } catch (err) {
            console.error("[CameraGrader] Capture failed:", err);
        } finally {
            setIsCapturing(false);
        }
    };

    const handlePickFromGallery = async () => {
        try {
            const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
            if (status !== "granted") return;

            const result = await ImagePicker.launchImageLibraryAsync({
                mediaTypes: ["images"],
                allowsMultipleSelection: !isSingle,
                quality: 0.92,
                selectionLimit: isSingle ? 1 : 50,
            });

            if (!result.canceled && result.assets && result.assets.length > 0) {
                if (isSingle) {
                    const singleUri = result.assets[0].uri;
                    if (onCaptureSingleSheet) {
                        onCaptureSingleSheet(singleUri);
                    } else {
                        onCaptureSheet(singleUri);
                    }
                    onClose();
                } else {
                    const uris = result.assets.map((a) => a.uri);
                    onBatchImportSheets(uris);
                }
            }
        } catch (err) {
            console.error("[CameraGrader] Gallery import failed:", err);
        }
    };

    if (!visible) return null;

    return (
        <Modal visible={visible} animationType="slide" transparent={false} onRequestClose={onClose}>
            <View style={styles.container}>
                {!permission || !permission.granted ? (
                    <View style={styles.permissionContainer}>
                        <Ionicons name="camera-outline" size={64} color="#F97316" />
                        <Text style={styles.permissionTitle}>Camera Permission Required</Text>
                        <Text style={styles.permissionSub}>
                            TSEKI requires camera access to scan and grade student test sheets.
                        </Text>
                        <TouchableOpacity style={[styles.permBtn, { backgroundColor: accentColor }]} onPress={requestPermission}>
                            <Text style={styles.permBtnText}>Grant Camera Access</Text>
                        </TouchableOpacity>
                        <TouchableOpacity style={styles.permCancel} onPress={onClose}>
                            <Text style={styles.permCancelText}>Cancel</Text>
                        </TouchableOpacity>
                    </View>
                ) : (
                    <View style={StyleSheet.absoluteFillObject}>
                        <CameraView
                            ref={cameraRef}
                            style={StyleSheet.absoluteFillObject}
                            facing="back"
                            enableTorch={flashMode === "on"}
                            barcodeScannerSettings={{ barcodeTypes: ["qr"] }}
                            onBarcodeScanned={handleBarcodeScanned}
                            onCameraReady={() => setCameraReady(true)}
                        />

                        {/* Shutter Flash Overlay */}
                        <Animated.View
                            pointerEvents="none"
                            style={[
                                StyleSheet.absoluteFillObject,
                                { backgroundColor: "#ffffff", opacity: flashAnim },
                            ]}
                        />

                        {/* Top Control Bar */}
                        <View style={styles.topBar}>
                            <TouchableOpacity style={styles.topBtn} onPress={onClose}>
                                <Ionicons name="close" size={24} color="#ffffff" />
                            </TouchableOpacity>

                            <View style={styles.headerInfo}>
                                <Text style={styles.headerTitle} numberOfLines={1}>
                                    {liveDetectedQuizTitle
                                        ? `Auto-Detected: ${liveDetectedQuizTitle}`
                                        : quizTitle === AUTO_DETECT_ASSESSMENT
                                        ? isSingle
                                            ? "Auto-Detect Assessment"
                                            : "Batch: Auto-Detect"
                                        : isSingle
                                        ? `Scan Sheet: ${quizTitle || "Test"}`
                                        : `Batch: ${quizTitle || "Test"}`}
                                </Text>
                                <Text style={styles.headerSub} numberOfLines={1}>
                                    {liveDetectedQuizTitle
                                        ? `${classTitle} · QR Locked`
                                        : classTitle}
                                </Text>
                            </View>

                            <View style={{ flexDirection: "row", alignItems: "center", gap: 8 }}>
                                <TouchableOpacity
                                    style={styles.topBtn}
                                    onPress={() => setGuidanceOpen(true)}
                                    activeOpacity={0.75}
                                >
                                    <Ionicons name="information-circle-outline" size={20} color="#ffffff" />
                                </TouchableOpacity>

                                <TouchableOpacity
                                    style={[styles.topBtn, flashMode === "on" && styles.topBtnActive]}
                                    onPress={() => setFlashMode((prev) => (prev === "on" ? "off" : "on"))}
                                >
                                    <Ionicons
                                        name={flashMode === "on" ? "flash" : "flash-off"}
                                        size={20}
                                        color={flashMode === "on" ? "#FBBF24" : "#ffffff"}
                                    />
                                </TouchableOpacity>
                            </View>
                        </View>

                        {/* ── Live Real-Time Hover Status HUD ── */}
                        <TouchableOpacity
                            style={styles.guidanceHud}
                            onPress={() => setGuidanceOpen(true)}
                            activeOpacity={0.85}
                        >
                            <View style={styles.guidanceItem}>
                                <Ionicons
                                    name={
                                        liveHoverStatus?.lighting === "too_dark"
                                            ? "moon"
                                            : liveHoverStatus?.lighting === "too_bright"
                                            ? "sunny"
                                            : "checkmark-circle"
                                    }
                                    size={13}
                                    color={
                                        !liveHoverStatus
                                            ? "#FBBF24"
                                            : liveHoverStatus.lighting === "ok"
                                            ? "#10B981"
                                            : "#EF4444"
                                    }
                                />
                                <Text
                                    style={[
                                        styles.guidanceText,
                                        liveHoverStatus && {
                                            color: liveHoverStatus.lighting === "ok" ? "#34D399" : "#FCA5A5",
                                        },
                                    ]}
                                >
                                    {!liveHoverStatus
                                        ? "Lighting"
                                        : liveHoverStatus.lighting === "too_dark"
                                        ? "Too Dark"
                                        : liveHoverStatus.lighting === "too_bright"
                                        ? "Too Bright"
                                        : "Light OK"}
                                </Text>
                            </View>
                            <Text style={styles.guidanceDivider}>•</Text>
                            <View style={styles.guidanceItem}>
                                <Ionicons
                                    name={
                                        !liveHoverStatus
                                            ? "sparkles"
                                            : liveHoverStatus.isBlurry
                                            ? "alert-circle"
                                            : "checkmark-circle"
                                    }
                                    size={13}
                                    color={
                                        !liveHoverStatus
                                            ? "#60A5FA"
                                            : liveHoverStatus.isBlurry
                                            ? "#F59E0B"
                                            : "#10B981"
                                    }
                                />
                                <Text
                                    style={[
                                        styles.guidanceText,
                                        liveHoverStatus && {
                                            color: liveHoverStatus.isBlurry ? "#FCD34D" : "#34D399",
                                        },
                                    ]}
                                >
                                    {!liveHoverStatus
                                        ? "Focus"
                                        : liveHoverStatus.isBlurry
                                        ? "Blurry!"
                                        : "Focus OK"}
                                </Text>
                            </View>
                            <Text style={styles.guidanceDivider}>•</Text>
                            <View style={styles.guidanceItem}>
                                <Ionicons
                                    name={liveHoverStatus?.cornerMarkersVisible ? "checkmark-circle" : "contract-outline"}
                                    size={13}
                                    color={
                                        !liveHoverStatus
                                            ? "#34D399"
                                            : liveHoverStatus.cornerMarkersVisible
                                            ? "#10B981"
                                            : "#F59E0B"
                                    }
                                />
                                <Text
                                    style={[
                                        styles.guidanceText,
                                        liveHoverStatus && {
                                            color: liveHoverStatus.cornerMarkersVisible ? "#34D399" : "#FCD34D",
                                        },
                                    ]}
                                >
                                    {liveHoverStatus
                                        ? `${liveHoverStatus.visibleCornerCount}/4 Markers`
                                        : "4 Markers"}
                                </Text>
                            </View>
                            <Text style={styles.guidanceDivider}>•</Text>
                            <View style={styles.guidanceItem}>
                                <Ionicons
                                    name={
                                        qrDetectedLive || liveHoverStatus?.qrVisible
                                            ? "checkmark-circle"
                                            : "qr-code-outline"
                                    }
                                    size={13}
                                    color={
                                        qrDetectedLive || liveHoverStatus?.qrVisible ? "#10B981" : "#F59E0B"
                                    }
                                />
                                <Text
                                    style={[
                                        styles.guidanceText,
                                        {
                                            color:
                                                qrDetectedLive || liveHoverStatus?.qrVisible
                                                    ? "#34D399"
                                                    : "#FCD34D",
                                        },
                                    ]}
                                >
                                    {qrDetectedLive || liveHoverStatus?.qrVisible ? "QR Ready" : "No QR"}
                                </Text>
                            </View>
                        </TouchableOpacity>

                        {/* ── Post-Capture Batch Photo Quality Warning Plaque (Batch Mode) ── */}
                        {activeQualityAlert && (() => {
                            const darkPalette = getSkeuoPalette(true);
                            const warnSem = getSemanticTokens("warning", true);
                            const errSem = getSemanticTokens("error", true);
                            return (
                                <View style={styles.qualityAlertBanner}>
                                    <View style={[styles.qualityAlertLedStrip, { backgroundColor: warnSem.ledBar, shadowColor: warnSem.led }]} />
                                    <View style={styles.qualityAlertHeader}>
                                        <View style={styles.qualityAlertTitleRow}>
                                            <View style={styles.qualityAlertIconSocket}>
                                                <Ionicons name="warning" size={14} color={warnSem.highlight} />
                                            </View>
                                            <Text style={styles.qualityAlertTitle} numberOfLines={1}>
                                                Photo Quality Alert: {activeQualityAlert.studentLabel}
                                            </Text>
                                        </View>
                                        <Pressable
                                            onPress={() => {
                                                triggerSkeuoHaptic("light");
                                                setActiveQualityAlert(null);
                                            }}
                                            style={({ pressed }) => [
                                                styles.qualityAlertCloseBtn,
                                                pressed && { opacity: 0.7 },
                                            ]}
                                            hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
                                            accessibilityLabel="Dismiss photo quality alert"
                                        >
                                            <Ionicons name="close" size={14} color="#CBD5E1" />
                                        </Pressable>
                                    </View>
                                    {activeQualityAlert.warnings.map((w, idx) => (
                                        <Text key={idx} style={styles.qualityAlertItem}>
                                            • {w}
                                        </Text>
                                    ))}
                                    <View style={styles.qualityAlertActions}>
                                        {activeQualityAlert.itemId && onRemoveSheet && (
                                            <Pressable
                                                style={({ pressed }) => [
                                                    styles.qualityAlertRetakeBtn,
                                                    skeuoButtonStyle(darkPalette, {
                                                        fill: errSem.fill,
                                                        highlight: errSem.highlight,
                                                        lip: errSem.lip,
                                                        pressed,
                                                        radius: 9,
                                                    }),
                                                ]}
                                                onPress={() => {
                                                    triggerSkeuoHaptic("medium");
                                                    const idToRemove = activeQualityAlert.itemId!;
                                                    setActiveQualityAlert(null);
                                                    onRemoveSheet(idToRemove);
                                                }}
                                            >
                                                <Ionicons name="refresh" size={13} color="#FFFFFF" />
                                                <Text style={styles.qualityAlertRetakeText}>Discard & Retake</Text>
                                            </Pressable>
                                        )}
                                        <Pressable
                                            style={({ pressed }) => [
                                                styles.qualityAlertDismissBtn,
                                                skeuoButtonStyle(darkPalette, {
                                                    neutral: true,
                                                    pressed,
                                                    radius: 9,
                                                }),
                                            ]}
                                            onPress={() => {
                                                triggerSkeuoHaptic("light");
                                                setActiveQualityAlert(null);
                                            }}
                                        >
                                            <Text style={styles.qualityAlertDismissText}>Dismiss</Text>
                                        </Pressable>
                                    </View>
                                </View>
                            );
                        })()}

                        {/* ── Interactive Tap-to-Focus Viewfinder Touch Layer ── */}
                        <TouchableWithoutFeedback onPress={handleTouchToFocus}>
                            <View style={StyleSheet.absoluteFillObject} />
                        </TouchableWithoutFeedback>

                        {/* ── Tap-to-Focus Pulsing Ring Indicator ── */}
                        {focusPoint && (
                            <Animated.View
                                style={[
                                    styles.focusRing,
                                    {
                                        left: focusPoint.x - 30,
                                        top: focusPoint.y - 30,
                                        opacity: focusAnim,
                                        transform: [
                                            {
                                                scale: focusAnim.interpolate({
                                                    inputRange: [0, 1],
                                                    outputRange: [1.35, 1],
                                                }),
                                            },
                                        ],
                                    },
                                ]}
                                pointerEvents="none"
                            />
                        )}

                        {/* ── Physical Paper Registration Reticle Guide with 4 Corner Markers ── */}
                        <View style={styles.reticleContainer} pointerEvents="box-none">
                            <View
                                style={[
                                    styles.reticleBox,
                                    liveHoverStatus && {
                                        borderColor: liveHoverStatus.hasWarnings
                                            ? "rgba(245, 158, 11, 0.75)"
                                            : "rgba(16, 185, 129, 0.85)",
                                    },
                                ]}
                            >
                                {/* Single Compact Status Pill Docked Cleanly at Top Edge of Scan Frame */}
                                {liveHoverStatus && !activeQualityAlert && (
                                    <View
                                        style={[
                                            styles.dockedStatusPill,
                                            liveHoverStatus.hasWarnings
                                                ? styles.liveStatusPillWarn
                                                : styles.liveStatusPillOk,
                                        ]}
                                        pointerEvents="none"
                                    >
                                        <Ionicons
                                            name={liveHoverStatus.hasWarnings ? "alert-circle" : "checkmark-circle"}
                                            size={13}
                                            color={liveHoverStatus.hasWarnings ? "#FBBF24" : "#34D399"}
                                        />
                                        <Text
                                            style={[
                                                styles.liveStatusText,
                                                { color: liveHoverStatus.hasWarnings ? "#FDE68A" : "#D1FAE5" },
                                            ]}
                                            numberOfLines={1}
                                        >
                                            {liveHoverStatus.hasWarnings
                                                ? liveHoverStatus.isBlurry
                                                    ? "Hold steady to focus"
                                                    : "Align QR code & 4 corners"
                                                : "Ready to capture"}
                                        </Text>
                                    </View>
                                )}

                                {/* Animated Scanning Laser Beam */}
                                <Animated.View
                                    pointerEvents="none"
                                    style={[
                                        styles.scanningLaserBeam,
                                        {
                                            backgroundColor: liveHoverStatus?.hasWarnings
                                                ? "#F59E0B"
                                                : (qrDetectedLive || liveHoverStatus?.qrVisible)
                                                ? "#10B981"
                                                : "#3B82F6",
                                            shadowColor: liveHoverStatus?.hasWarnings
                                                ? "#F59E0B"
                                                : (qrDetectedLive || liveHoverStatus?.qrVisible)
                                                ? "#10B981"
                                                : "#60A5FA",
                                            transform: [
                                                {
                                                    translateY: scanLaserAnim.interpolate({
                                                        inputRange: [0, 1],
                                                        outputRange: [6, RETICLE_HEIGHT - 12],
                                                    }),
                                                },
                                            ],
                                        },
                                    ]}
                                >
                                    <View
                                        style={[
                                            styles.laserGlowTrail,
                                            {
                                                backgroundColor: liveHoverStatus?.hasWarnings
                                                    ? "rgba(245, 158, 11, 0.22)"
                                                    : (qrDetectedLive || liveHoverStatus?.qrVisible)
                                                    ? "rgba(16, 185, 129, 0.22)"
                                                    : "rgba(59, 130, 246, 0.22)",
                                            },
                                        ]}
                                    />
                                </Animated.View>

                                {/* Top-Left Corner Bracket & Solid Marker Target */}
                                <Animated.View
                                    style={[
                                        styles.corner,
                                        styles.cornerTL,
                                        { transform: [{ scale: cornerPulseAnim }] },
                                        liveHoverStatus && {
                                            borderColor: liveHoverStatus.cornerStatus.tl ? "#10B981" : "#F59E0B",
                                        },
                                    ]}
                                >
                                    <View
                                        style={[
                                            styles.markerTargetSquare,
                                            liveHoverStatus?.cornerStatus.tl && { borderColor: "#10B981" },
                                        ]}
                                    />
                                </Animated.View>

                                {/* Top-Right Corner Bracket & Solid Marker Target */}
                                <Animated.View
                                    style={[
                                        styles.corner,
                                        styles.cornerTR,
                                        { transform: [{ scale: cornerPulseAnim }] },
                                        liveHoverStatus && {
                                            borderColor: liveHoverStatus.cornerStatus.tr ? "#10B981" : "#F59E0B",
                                        },
                                    ]}
                                >
                                    <View
                                        style={[
                                            styles.markerTargetSquare,
                                            liveHoverStatus?.cornerStatus.tr && { borderColor: "#10B981" },
                                        ]}
                                    />
                                </Animated.View>

                                {/* Bottom-Left Corner Bracket & Solid Marker Target */}
                                <Animated.View
                                    style={[
                                        styles.corner,
                                        styles.cornerBL,
                                        { transform: [{ scale: cornerPulseAnim }] },
                                        liveHoverStatus && {
                                            borderColor: liveHoverStatus.cornerStatus.bl ? "#10B981" : "#F59E0B",
                                        },
                                    ]}
                                >
                                    <View
                                        style={[
                                            styles.markerTargetSquare,
                                            liveHoverStatus?.cornerStatus.bl && { borderColor: "#10B981" },
                                        ]}
                                    />
                                </Animated.View>

                                {/* Bottom-Right Corner Bracket & Solid Marker Target */}
                                <Animated.View
                                    style={[
                                        styles.corner,
                                        styles.cornerBR,
                                        { transform: [{ scale: cornerPulseAnim }] },
                                        liveHoverStatus && {
                                            borderColor: liveHoverStatus.cornerStatus.br ? "#10B981" : "#F59E0B",
                                        },
                                    ]}
                                >
                                    <View
                                        style={[
                                            styles.markerTargetSquare,
                                            liveHoverStatus?.cornerStatus.br && { borderColor: "#10B981" },
                                        ]}
                                    />
                                </Animated.View>
                            </View>
                        </View>

                        {/* Bottom Controls Area */}
                        <View style={styles.bottomArea}>
                            {/* Live Thumbnail Feed of Scanned Sheets (Batch Mode only) */}
                            {!isSingle && recentThumbnails.length > 0 && (
                                <View style={styles.thumbnailRow}>
                                    <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.thumbScroll}>
                                        {recentThumbnails.map((uri, idx) => (
                                            <View key={uri + idx} style={styles.thumbWrap}>
                                                <Image source={{ uri }} style={styles.thumbImg} />
                                                <View style={styles.thumbBadge}>
                                                    <Ionicons name="checkmark-circle" size={14} color="#10B981" />
                                                </View>
                                            </View>
                                        ))}
                                    </ScrollView>
                                </View>
                            )}

                            {/* Main Shutter Bar */}
                            <View style={styles.shutterBar}>
                                {/* Photo Library Import */}
                                <TouchableOpacity
                                    style={[
                                        styles.galleryBtn,
                                        {
                                            backgroundColor: "rgba(30, 34, 42, 0.88)",
                                            borderWidth: 1,
                                            borderTopColor: "rgba(255, 255, 255, 0.22)",
                                            borderBottomColor: "rgba(0, 0, 0, 0.7)",
                                            borderBottomWidth: 3,
                                        },
                                    ]}
                                    onPress={handlePickFromGallery}
                                    activeOpacity={0.75}
                                >
                                    <Ionicons name="images" size={24} color="#ffffff" />
                                    <Text style={styles.galleryBtnLabel}>Album</Text>
                                </TouchableOpacity>

                                {/* Snap Shutter Button */}
                                <TouchableOpacity
                                    style={[
                                        styles.shutterRing,
                                        {
                                            borderColor: "rgba(255, 255, 255, 0.85)",
                                            backgroundColor: "rgba(18, 20, 24, 0.65)",
                                            shadowColor: "#000000",
                                            shadowOffset: { width: 0, height: 4 },
                                            shadowOpacity: 0.5,
                                            shadowRadius: 8,
                                            elevation: 8,
                                        },
                                    ]}
                                    onPress={handleSnap}
                                    activeOpacity={0.8}
                                    disabled={isCapturing}
                                >
                                    <View
                                        style={[
                                            styles.shutterInner,
                                            {
                                                backgroundColor: accentColor,
                                                borderTopWidth: 2,
                                                borderTopColor: "rgba(255, 255, 255, 0.45)",
                                                borderBottomWidth: 3,
                                                borderBottomColor: "rgba(0, 0, 0, 0.35)",
                                            },
                                        ]}
                                    >
                                        {isCapturing ? (
                                            <ActivityIndicator size="small" color="#ffffff" />
                                        ) : (
                                            <Ionicons name="camera" size={32} color="#ffffff" />
                                        )}
                                    </View>
                                </TouchableOpacity>

                                {/* Single Mode: Tips Button | Batch Mode: Review Button */}
                                {isSingle ? (
                                    <TouchableOpacity
                                        style={[
                                            styles.singleTipsBtn,
                                            {
                                                backgroundColor: "rgba(30, 34, 42, 0.88)",
                                                borderWidth: 1,
                                                borderTopColor: "rgba(255, 255, 255, 0.22)",
                                                borderBottomColor: "rgba(0, 0, 0, 0.7)",
                                                borderBottomWidth: 3,
                                            },
                                        ]}
                                        onPress={() => setGuidanceOpen(true)}
                                        activeOpacity={0.75}
                                    >
                                        <Ionicons name="bulb-outline" size={22} color="#FBBF24" />
                                        <Text style={styles.singleTipsBtnLabel}>Tips</Text>
                                    </TouchableOpacity>
                                ) : (
                                    <TouchableOpacity
                                        style={[
                                            styles.finishBtn,
                                            {
                                                borderTopWidth: 1,
                                                borderTopColor: "rgba(255, 255, 255, 0.3)",
                                                borderBottomWidth: 3,
                                                borderBottomColor: "rgba(0, 0, 0, 0.45)",
                                            },
                                            totalCaptured === 0 && styles.finishBtnDisabled,
                                        ]}
                                        onPress={onFinishAndReview}
                                        disabled={totalCaptured === 0}
                                        activeOpacity={0.85}
                                    >
                                        {inProgressCount > 0 && (
                                            <ActivityIndicator size="small" color="#ffffff" style={{ marginRight: 2 }} />
                                        )}
                                        <Text style={styles.finishBtnText}>
                                            Review ({totalCaptured}) →
                                        </Text>
                                    </TouchableOpacity>
                                )}
                            </View>
                        </View>

                        {/* Photo Guidance Dialog */}
                        <PhotoGuidanceModal
                            visible={guidanceOpen}
                            onClose={() => setGuidanceOpen(false)}
                            accentColor={accentColor}
                        />
                    </View>
                )}
            </View>
        </Modal>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: "#000000",
    },
    permissionContainer: {
        flex: 1,
        backgroundColor: "#111827",
        alignItems: "center",
        justifyContent: "center",
        padding: 32,
    },
    permissionTitle: {
        color: "#F9FAFB",
        fontSize: 20,
        fontWeight: "800",
        marginTop: 16,
        textAlign: "center",
    },
    permissionSub: {
        color: "#9CA3AF",
        fontSize: 14,
        textAlign: "center",
        lineHeight: 20,
        marginTop: 8,
        marginBottom: 24,
    },
    permBtn: {
        paddingHorizontal: 24,
        paddingVertical: 14,
        borderRadius: 12,
        width: "100%",
        alignItems: "center",
    },
    permBtnText: {
        color: "#ffffff",
        fontSize: 15,
        fontWeight: "700",
    },
    permCancel: {
        marginTop: 14,
        padding: 8,
    },
    permCancelText: {
        color: "#9CA3AF",
        fontSize: 14,
        fontWeight: "600",
    },
    topBar: {
        position: "absolute",
        top: 48,
        left: 0,
        right: 0,
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between",
        paddingHorizontal: 16,
        zIndex: 10,
    },
    topBtn: {
        width: 38,
        height: 38,
        borderRadius: 19,
        backgroundColor: "rgba(0,0,0,0.5)",
        alignItems: "center",
        justifyContent: "center",
    },
    topBtnActive: {
        backgroundColor: "rgba(251,191,36,0.3)",
        borderWidth: 1.5,
        borderColor: "#FBBF24",
    },
    headerInfo: {
        flex: 1,
        alignItems: "center",
        marginHorizontal: 8,
    },
    headerTitle: {
        color: "#ffffff",
        fontSize: 14,
        fontWeight: "700",
    },
    headerSub: {
        color: "rgba(255,255,255,0.75)",
        fontSize: 11,
        fontWeight: "500",
    },
    guidanceHud: {
        position: "absolute",
        top: 98,
        alignSelf: "center",
        flexDirection: "row",
        alignItems: "center",
        backgroundColor: "rgba(17, 24, 39, 0.88)",
        borderRadius: 20,
        paddingVertical: 6,
        paddingHorizontal: 14,
        borderWidth: 1,
        borderColor: "rgba(255, 255, 255, 0.2)",
        zIndex: 10,
        shadowColor: "#000",
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.3,
        shadowRadius: 4,
    },
    guidanceItem: {
        flexDirection: "row",
        alignItems: "center",
        gap: 4,
    },
    guidanceText: {
        color: "#FFFFFF",
        fontSize: 11,
        fontWeight: "700",
    },
    guidanceDivider: {
        color: "rgba(255, 255, 255, 0.4)",
        marginHorizontal: 8,
        fontSize: 10,
    },
    dockedStatusPill: {
        position: "absolute",
        top: -15,
        alignSelf: "center",
        flexDirection: "row",
        alignItems: "center",
        gap: 6,
        paddingVertical: 5,
        paddingHorizontal: 12,
        borderRadius: 14,
        borderWidth: 1,
        zIndex: 20,
        shadowColor: "#000",
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.3,
        shadowRadius: 4,
    },
    liveStatusPillWarn: {
        backgroundColor: "rgba(17, 24, 39, 0.94)",
        borderColor: "#F59E0B",
    },
    liveStatusPillOk: {
        backgroundColor: "rgba(6, 78, 59, 0.94)",
        borderColor: "#10B981",
    },
    liveStatusText: {
        fontSize: 11.5,
        fontWeight: "700",
    },
    reticleContainer: {
        ...StyleSheet.absoluteFillObject,
        alignItems: "center",
        justifyContent: "center",
        zIndex: 1,
    },
    reticleBox: {
        width: SCREEN_WIDTH * 0.88,
        height: Math.min(SCREEN_WIDTH * 0.88 * 1.30, SCREEN_HEIGHT * 0.54),
        marginBottom: 20,
        position: "relative",
        borderWidth: 1.5,
        borderColor: "rgba(255, 255, 255, 0.4)",
        borderStyle: "dashed",
        borderRadius: 10,
        backgroundColor: "rgba(255, 255, 255, 0.02)",
    },
    corner: {
        position: "absolute",
        width: 36,
        height: 36,
        borderColor: "#ffffff",
        alignItems: "center",
        justifyContent: "center",
    },
    cornerTL: {
        top: -2,
        left: -2,
        borderTopWidth: 4,
        borderLeftWidth: 4,
        borderTopLeftRadius: 8,
    },
    cornerTR: {
        top: -2,
        right: -2,
        borderTopWidth: 4,
        borderRightWidth: 4,
        borderTopRightRadius: 8,
    },
    cornerBL: {
        bottom: -2,
        left: -2,
        borderBottomWidth: 4,
        borderLeftWidth: 4,
        borderBottomLeftRadius: 8,
    },
    cornerBR: {
        bottom: -2,
        right: -2,
        borderBottomWidth: 4,
        borderRightWidth: 4,
        borderBottomRightRadius: 8,
    },
    markerTargetSquare: {
        width: 16,
        height: 16,
        backgroundColor: "#000000",
        borderWidth: 1.5,
        borderColor: "#FFFFFF",
        borderRadius: 2,
    },
    scanningLaserBeam: {
        position: "absolute",
        left: 8,
        right: 8,
        height: 2.5,
        borderRadius: 2,
        zIndex: 4,
        shadowOffset: { width: 0, height: 0 },
        shadowOpacity: 0.9,
        shadowRadius: 6,
        elevation: 6,
    },
    laserGlowTrail: {
        position: "absolute",
        top: -14,
        bottom: -14,
        left: 0,
        right: 0,
        borderRadius: 8,
    },
    qrTargetBox: {
        position: "absolute",
        top: 42,
        right: 4,
        flexDirection: "row",
        alignItems: "center",
        gap: 3,
        paddingHorizontal: 5,
        paddingVertical: 3,
        borderWidth: 1.5,
        borderColor: "rgba(255, 255, 255, 0.8)",
        borderRadius: 4,
        backgroundColor: "rgba(0, 0, 0, 0.4)",
    },
    qrTargetBoxActive: {
        borderColor: "#10B981",
        backgroundColor: "rgba(6, 78, 59, 0.85)",
    },
    qrTargetText: {
        color: "#FFFFFF",
        fontSize: 9,
        fontWeight: "800",
    },
    qualityAlertBanner: {
        position: "absolute",
        top: 136,
        left: 16,
        right: 16,
        backgroundColor: "rgba(24, 27, 34, 0.96)",
        borderRadius: 14,
        paddingVertical: 12,
        paddingRight: 13,
        paddingLeft: 16,
        borderWidth: 1,
        borderTopColor: "#5C431C",
        borderLeftColor: "#6C4A15",
        borderRightColor: "#6C4A15",
        borderBottomColor: "#0B0D10",
        borderBottomWidth: 3,
        overflow: "hidden",
        zIndex: 25,
        shadowColor: "#000",
        shadowOffset: { width: 0, height: 8 },
        shadowOpacity: 0.48,
        shadowRadius: 14,
        elevation: 10,
    },
    qualityAlertLedStrip: {
        position: "absolute",
        left: 0,
        top: 0,
        bottom: 0,
        width: 4,
        shadowOffset: { width: 1, height: 0 },
        shadowOpacity: 0.7,
        shadowRadius: 5,
    },
    qualityAlertHeader: {
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between",
        marginBottom: 7,
    },
    qualityAlertTitleRow: {
        flexDirection: "row",
        alignItems: "center",
        gap: 8,
        flex: 1,
        marginRight: 8,
    },
    qualityAlertIconSocket: {
        width: 24,
        height: 24,
        borderRadius: 7,
        backgroundColor: "#201708",
        borderWidth: 1,
        borderTopColor: "#0B0D10",
        borderLeftColor: "#0B0D10",
        borderRightColor: "#80581A",
        borderBottomColor: "#80581A",
        alignItems: "center",
        justifyContent: "center",
    },
    qualityAlertCloseBtn: {
        width: 26,
        height: 26,
        borderRadius: 8,
        backgroundColor: "rgba(255,255,255,0.08)",
        borderWidth: 1,
        borderColor: "rgba(255,255,255,0.12)",
        alignItems: "center",
        justifyContent: "center",
    },
    qualityAlertTitle: {
        color: "#FCD34D",
        fontSize: 13,
        fontWeight: "800",
        flex: 1,
    },
    qualityAlertItem: {
        color: "#E7E5E4",
        fontSize: 11.5,
        lineHeight: 16.5,
        marginTop: 2,
    },
    qualityAlertActions: {
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "flex-end",
        gap: 8,
        marginTop: 10,
    },
    qualityAlertRetakeBtn: {
        flexDirection: "row",
        alignItems: "center",
        gap: 5,
        paddingVertical: 7,
        paddingHorizontal: 11,
    },
    qualityAlertRetakeText: {
        color: "#FFFFFF",
        fontSize: 11.5,
        fontWeight: "700",
    },
    qualityAlertDismissBtn: {
        paddingVertical: 7,
        paddingHorizontal: 11,
    },
    qualityAlertDismissText: {
        color: "#F4F2ED",
        fontSize: 11.5,
        fontWeight: "700",
    },
    focusRing: {
        position: "absolute",
        width: 60,
        height: 60,
        borderRadius: 30,
        borderWidth: 2,
        borderColor: "#FBBF24",
        backgroundColor: "rgba(251, 191, 36, 0.15)",
        zIndex: 99,
    },
    bottomArea: {
        position: "absolute",
        bottom: 24,
        left: 0,
        right: 0,
        alignItems: "center",
        zIndex: 10,
    },
    thumbnailRow: {
        height: 54,
        width: "100%",
        marginBottom: 16,
        paddingHorizontal: 16,
    },
    thumbScroll: {
        alignItems: "center",
        gap: 8,
    },
    thumbWrap: {
        width: 44,
        height: 52,
        borderRadius: 6,
        overflow: "hidden",
        borderWidth: 1.5,
        borderColor: "#ffffff",
        position: "relative",
    },
    thumbImg: {
        width: "100%",
        height: "100%",
        resizeMode: "cover",
    },
    thumbBadge: {
        position: "absolute",
        bottom: 2,
        right: 2,
        backgroundColor: "rgba(0,0,0,0.6)",
        borderRadius: 8,
    },
    shutterBar: {
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between",
        width: "100%",
        paddingHorizontal: 28,
    },
    galleryBtn: {
        alignItems: "center",
        justifyContent: "center",
        width: 54,
        height: 54,
        borderRadius: 27,
        backgroundColor: "rgba(255,255,255,0.2)",
    },
    galleryBtnLabel: {
        color: "#ffffff",
        fontSize: 10,
        fontWeight: "700",
        marginTop: 2,
    },
    singleTipsBtn: {
        alignItems: "center",
        justifyContent: "center",
        width: 54,
        height: 54,
        borderRadius: 27,
        backgroundColor: "rgba(255,255,255,0.2)",
    },
    singleTipsBtnLabel: {
        color: "#ffffff",
        fontSize: 10,
        fontWeight: "700",
        marginTop: 2,
    },
    shutterRing: {
        width: 82,
        height: 82,
        borderRadius: 41,
        borderWidth: 4,
        borderColor: "#ffffff",
        alignItems: "center",
        justifyContent: "center",
        backgroundColor: "transparent",
    },
    shutterInner: {
        width: 68,
        height: 68,
        borderRadius: 34,
        alignItems: "center",
        justifyContent: "center",
    },
    finishBtn: {
        flexDirection: "row",
        alignItems: "center",
        gap: 6,
        backgroundColor: "#10B981",
        paddingVertical: 12,
        paddingHorizontal: 16,
        borderRadius: 24,
    },
    finishBtnDisabled: {
        backgroundColor: "rgba(255,255,255,0.2)",
        opacity: 0.5,
    },
    finishBtnContent: {
        flexDirection: "row",
        alignItems: "center",
        gap: 6,
    },
    finishBtnText: {
        color: "#ffffff",
        fontSize: 13.5,
        fontWeight: "800",
    },
    finishBadge: {
        backgroundColor: "rgba(0,0,0,0.25)",
        paddingHorizontal: 7,
        paddingVertical: 2,
        borderRadius: 10,
    },
    finishBadgeText: {
        color: "#ffffff",
        fontSize: 12,
        fontWeight: "800",
    },
});
