import react from '@vitejs/plugin-react'
import { defineConfig } from 'vite'

export default defineConfig({
  plugins: [react()],
  envDir: '..',
  envPrefix: ['VITE_', 'EXPO_PUBLIC_'],
  server: {
    host: '0.0.0.0',
    port: 3000,
    allowedHosts: true,
  },
})
