import { createClient } from "@supabase/supabase-js";

// Check Vite-specific (VITE_) and Expo-shared (EXPO_PUBLIC_) environment variables
const supabaseUrl =
  import.meta.env.VITE_SUPABASE_URL ||
  import.meta.env.EXPO_PUBLIC_SUPABASE_URL;

const supabaseAnonKey =
  import.meta.env.VITE_SUPABASE_ANON_KEY ||
  import.meta.env.EXPO_PUBLIC_SUPABASE_ANON_KEY;

export const isSupabaseConfigured = Boolean(
  supabaseUrl &&
    supabaseAnonKey &&
    !supabaseUrl.includes("your-project.supabase.co") &&
    !supabaseUrl.includes("placeholder.supabase.co")
);

if (!isSupabaseConfigured) {
  console.warn(
    "Supabase configuration missing. Define VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY in your environment variables to enable authentication and cloud sync."
  );
}

export const supabase = createClient(
  supabaseUrl || "https://placeholder.supabase.co",
  supabaseAnonKey || "placeholder-anon-key",
  {
    auth: {
      autoRefreshToken: true,
      persistSession: true,
      detectSessionInUrl: true,
    },
  }
);
